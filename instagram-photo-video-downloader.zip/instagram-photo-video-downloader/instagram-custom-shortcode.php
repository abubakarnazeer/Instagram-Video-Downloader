<?php 
/**
 * Plugin Name:       Instagram Photo Video Downloader
 * Plugin URI:        
 * Description:       Create Gameslotstudio
 * Version:           1.0.0
 * Author:            Logic Squares
 * License:           GNU General Public License v2
 * Text Domain:       WM
 * Network:           true
 * GitHub Plugin URI: 
 * Requires WP:       5.0.3
 * Requires PHP:      7.4
 * Date 09/08/2022
 */



define( 'INSTAGRAM__PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'INSTAGRAM__VERSION', '1.0.3' );

require_once( INSTAGRAM__PLUGIN_DIR . 'class.instagramphotodownloader.php' );

add_action( 'init', array( 'Instagramdownloader', 'init' ) );
add_shortcode( 'instagram-downloader-video-photo', array( 'Instagramdownloader', 'downloaderinstagramshortcode' ) );



