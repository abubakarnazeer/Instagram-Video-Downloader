<?php 
//Security Check
if(count(get_included_files()) ==1) exit("No direct script access allowed.");
?>
<section class="features-icons bg-pink text-center text-white">
      <div class="container">
        <div class="row">
          <div class="col-lg-4">
            <div class="features-icons-item mx-auto mb-5 mb-lg-0 mb-lg-3">
              <div class="features-icons-icon d-flex">
                <i class="icon-like m-auto text-white"></i>
              </div>
              <h3>Supports every Video</h3>
              <p class="lead mb-0">Download any video in multiple qualities from Instagram.</p>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="features-icons-item mx-auto mb-5 mb-lg-0 mb-lg-3">
              <div class="features-icons-icon d-flex">
                <i class="icon-info m-auto text-white"></i>
              </div>
              <h3>Carousel</h3>
              <p class="lead mb-0">Carousel videos and images are supported.</p>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="features-icons-item mx-auto mb-0 mb-lg-3">
              <div class="features-icons-icon d-flex">
                <i class="icon-energy m-auto text-white"></i>
              </div>
              <h3>Fast Downloads</h3>
              <p class="lead mb-0">Get lighting fast download speed without any limit.</p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="instructions text-center bg-light">
      <div class="container">
        <h2 class="mb-5 text-pink">How to Download?</h2>
        <div class="row">
          <div class="col-lg-8 mx-auto">
            <ul class="list-group text-left text-secondary mb-5">
              <li class="list-group-item">
                <span class="badge badge-dark badge-pill mr-2">1.</span>Open the video you'd like to download from Instagram.
              </li>
              <li class="list-group-item">
                <span class="badge badge-dark badge-pill mr-2">2.</span>Click on three dots and choose Copy Link.
              </li>
              <li class="list-group-item">
                <span class="badge badge-dark badge-pill mr-2">3.</span>Paste the url above and hit submit button.
              </li>
              <li class="list-group-item">
                <span class="badge badge-dark badge-pill mr-2">4.</span>Click on the download button to start downloading.
              </li>
            </ul>
            <?php get_ad("ad300"); ?>
          </div>
        </div>
      </div>
    </section>

    <!-- Footer -->
    <footer class="footer bg-dark footer-white-links">
      <div class="container">
        <div class="row">
          <div class="col-lg-6 h-100 text-center text-lg-left my-auto">
            <ul class="list-inline mb-2">
              <li class="list-inline-item">
                <a href="index.php">Home</a>
              </li>
            </ul>
            <p class="text-muted small mb-4 mb-lg-0">Instagram Downloader <?php echo VERSION; ?> Made with <i class="fa fa-heart text-danger"></i> by <a href="https://www.codester.com/WpEliteMedia/" target="_blank">WpEliteMedia</a> - <?php echo date('Y', time()); ?></p>
          </div>
          <div class="col-lg-6 h-100 text-center text-lg-right my-auto">
            <ul class="list-inline mb-0">
              <li class="list-inline-item mr-3">
                <a href="https://www.facebook.com" target="_blank">
                  <i class="fa fa-facebook fa-2x fa-fw"></i>
                </a>
              </li>
              <li class="list-inline-item mr-3">
                <a href="#">
                  <i class="fa fa-twitter-square fa-2x fa-fw"></i>
                </a>
              </li>
              <li class="list-inline-item">
                <a href="#">
                  <i class="fa fa-instagram fa-2x fa-fw"></i>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="content/js/jquery.min.js"></script>
    <script src="content/js/bootstrap.bundle.min.js"></script>