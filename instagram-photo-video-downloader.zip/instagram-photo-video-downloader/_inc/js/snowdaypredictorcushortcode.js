$( document ).ready(function() {
 
  
 
});



function genratenewanmes(){


  var listofids = [];
  var urlnew = window.location.origin + '/wp-admin/admin-ajax.php';

                  var data = new FormData();
                

                  var numberofinputs = jQuery("#namemixinpurts").val();
                  data.append('zipcode', numberofinputs);
                  data.append('action', 'loadfrm');
                 

                 
                  jQuery.ajax({
                      url:urlnew,
                      data: data,
                      cache: false,
                      contentType: false,
                      processData: false,
                      type: 'POST',
                      success: function(data) {

                        var responce = jQuery.parseJSON(data);
                        jQuery("#errormsg").empty();
                      

            
                        if(responce.status == "failed"){

                         jQuery("#errormsg").append('Zip / Postal code is not vaild please try with a vaild code');

                        }else{

                        
                          const chart = Highcharts.charts[0];

                          chart.setTitle({ text: 'Snow Day Predictor In  '+responce.cityname});
                          if (chart && !chart.renderer.forExport) {

                              const point = chart.series[0].points[0],
                                  inc = Math.round((Math.random() - 0.5) * 20);
                      
                             
                      
                              point.update(responce.snowprediction);
                          }

                          jQuery(".mycontentdiv").hide();
                          jQuery("#container").show();
                          jQuery(".tryaginbutton").show();
                         
                          
                        

                        }


                       

                      }
                  });

         


}

function reloadpage(){



  location.reload();
}

jQuery(document).ready( function () {
    
    var urlnew = window.location.origin + '/wp-admin/admin-ajax.php';
    var data = new FormData();
  
    
  
          
  
          
  
            jQuery("#namemixinpurts").keyup(function(){
  
              
              var value = jQuery("#namemixinpurts").val();
  
              if(value.length >= 3){  
  
               
               
                data.append('keysearch', jQuery("#namemixinpurts").val());
                data.append('action', 'searchfilter');
  
                    jQuery.ajax({
                        url:urlnew,
                        data: data,
                        cache: false,
                        contentType: false,
                        processData: false,
                        type: 'POST',
                        success: function(data) {
  
                          var message = jQuery.parseJSON(data);
                          jQuery("#showList1").remove();
                          var html = '<div id="showList1" style="overflow-y: auto;max-height: 216px;"> <ul class="list-group">';
                         
                          
                          jQuery.each(message, function (index, value) {
  
  
  
                            html +="<li class='list-group-item list1'>"+value+"</li>";
  
  
                          });
                        
                          html += "</ul></div>";
  
                          jQuery(html).insertAfter("#namemixinpurts");
                          console.log(html);
  
                        }
                      });
                  }else{
  
  
                    jQuery("#showList1").remove();
  
  
                  }
                });
  
             
      
        
                  
  });
  
  jQuery(document).on('click','.list1',function(){
    jQuery("#namemixinpurts").val(jQuery(this).text());
    jQuery('#showList1').remove();
  });