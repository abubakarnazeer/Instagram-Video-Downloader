<?php



class Instagramdownloader {

	

    private static $initiated = false;

    public static function init() {
		if ( ! self::$initiated ) {
			self::init_hooks();
		}
	}



    public static function downloaderinstagramshortcode( $atts ) {
        
       
        $dir = site_url().'/wp-content/plugins/instagram-photo-video-downloader/';
       
        $outputform .= '<input type="hidden" id="plugindir" value="'.$dir.'"> <div class="row"><div class="col-md-12"><form method="POST" action="javascript:void(0)" id="form"><div class="download-input mb-4"><div class="input-group input-group-lg"><input type="text" id="url" class="form-control" placeholder="'.$atts['placeholder'].'"><div class="input-group-append"><button class="btn btn-blue btn-info" style="background-color: #002052;border-color: #002052;" id="form_submit" type="submit">Download </button> </div>   </div></div> </form> <i class="fa fa-circle-o-notch fa-3x fa-spin mb-4" id="loading-ajax" style="display: none;"></i> <div id="downloadbox"></div></div></div>';
        
        return $outputform;
    }


 


  

    private static function init_hooks() {
        
		self::$initiated = true;
        
        wp_register_style( 'bootstrapstyle', '//cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css',array(), INSTAGRAM__VERSION );
        wp_enqueue_style( 'bootstrapstyle' );

        wp_register_style( 'nmstyle', plugin_dir_url( __FILE__ ) . '_inc/css/nmstyle.css', array(), INSTAGRAM__VERSION );
        wp_enqueue_style( 'nmstyle' );
     
     
        wp_register_script( 'ajaxjquery.js', '//code.jquery.com/jquery-3.6.0.min.js', array(), INSTAGRAM__VERSION );
		wp_enqueue_script( 'ajaxjquery.js');


        wp_register_script( 'content.js', plugin_dir_url( __FILE__ ) . 'content/js/ajax.js', array(), INSTAGRAM__VERSION );
		wp_enqueue_script( 'content.js');

        wp_register_script( 'bootstrap.js', '//cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js', array(), INSTAGRAM__VERSION );
		wp_enqueue_script( 'bootstrap.js');

        


    }
    
    /** Plugin dependencies   -- End -- */

}